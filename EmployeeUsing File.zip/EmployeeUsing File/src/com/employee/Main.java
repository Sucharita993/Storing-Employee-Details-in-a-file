package com.employee;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		try {
			File file = new File("Data.txt");
			file.createNewFile();
			PrintWriter pw = new PrintWriter(new FileOutputStream(file, true));

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			List<Employee> employee = new ArrayList<Employee>();
			int Choice = 0;
			int select = 0;

			do {
				System.out.print("\n\n1.CREATE\n2.DISPLAY\n3.RAISESALARY\n4.EXIT\nEnter your choice!!");
				Choice = Integer.parseInt(br.readLine());
				switch (Choice) {
				case 1: {
					do {
						System.out.print("\n\n1.CLERK\n2.MANAGER\n3.PROGRAMMER\n4.EXIT\nEnter your choice!!");
						select = Integer.parseInt(br.readLine());
						Employee emp = null;
						switch (select) {
						case 1:
							emp = new Clerk();
							break;
						case 2:
							emp = new Manager();
							break;
						case 3:
							emp = new Programmer();
							break;
						case 4:
							break;
						default:
							System.out.print("\n\ninvalid entry...!");
							break;
						}
						if (select == 1 || select == 2 || select == 3) {
							boolean existing = false;
							for (Employee k : employee) {
								if (k.name.equals(emp.name) && k.age == emp.age) {
									System.out.print("\nRecord already exists...");
									existing = true;
									break;
								}
							}
							if (!existing) {
								employee.add(emp);
								pw.println("Name is :" + emp.name);
								pw.println("Age is :" + emp.age);
								pw.println("Sal is :" + emp.salary);
								pw.println("Desig is :" + emp.designation);
								pw.flush();

							}
						}
					} while (select != 4);
					break;
				}
				case 2: {
					if (employee.size() == 0) {
						System.out.print("\nNorecords found.....!!");
						break;
					}
					for (Employee e : employee)
						e.display();
					break;
				}
				case 3: {
					if (employee.size() == 0) {
						System.out.print("\nNorecords found.....!!");
						break;
					}
					for (Employee e : employee)
						e.raiseSalary();
					System.out.print("\nSalary raised...");
					break;
				}
				case 4:
					System.out.print("\nExiting....!!");
					break;
				default:
					System.out.print("\nInvalid choice....!!");

				}
			} while (Choice != 4);

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
