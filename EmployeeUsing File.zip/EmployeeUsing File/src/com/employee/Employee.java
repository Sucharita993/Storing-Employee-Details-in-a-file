package com.employee;

import java.io.BufferedReader;
import java.io.InputStreamReader;

	abstract class Employee {
		String name, designation;
		int age, salary;

		public Employee() {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				System.out.print("\n Enter Name ");
				name = br.readLine();
				System.out.print("\nEnter Age : ");
				age = Integer.parseInt(br.readLine());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void display() {
			System.out.println("Name is :" + name);
			System.out.println("Age is :" + age);
			System.out.println("Salary is :" + salary);
			System.out.println("Designation is :" + designation);
		}

		public abstract void raiseSalary();
	}

	final class Clerk extends Employee {
		public Clerk() {
			designation = "Clerk";
			salary = 15000;
		}

		public void raiseSalary() {
			salary += 1000;
		}

	}

	final class Manager extends Employee {
		public Manager() {
			designation = "Manager";
			salary = 40000;
		}

		public void raiseSalary() {
			salary += 2000;
		}
	}

	final class Programmer extends Employee {
		public Programmer() {
			designation = "Programmer";
			salary = 35000;
		}

		public void raiseSalary() {
			salary += 1500;
		}
}

